{{
    config(
        tags=['staging']
    )
}}
 
with
columns_conversion as (
    SELECT 
    SUBSTRING(userid, 8) AS Internid,
    username as Name,
    gender,
    SUBSTRING(trainerid, 4) as Trainerid,
    trainingname as trainingname,
    trainername,
    modulescompleted as modules,
    Progress as progress,
    assessmentscores as scores,
    startdate,
    enddate
    from {{ source('training', 'intern') }}
),
type_conversion as (
    select 
    cast(Internid as int) as Internid,
    Name,
    cast(trainerid as int) as trainerid,
    trainername,
    trainingname,
    progress,
    scores,
    startdate,
    enddate
 from columns_conversion
)


select * from type_conversion