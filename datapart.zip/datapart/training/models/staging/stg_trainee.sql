{{
    config(
        tags=['staging']
    )
}}
with traine as (
    select 
    SUBSTRING (trainer_id, 4) as Trainerid,
    trainer_name as trainername,
    Specifications as domain,
    department,
    experience
    from {{source('training', 'trainee') }}
),
typo as (
    select
    cast(trainerid as int) as trainerid,
    trainername,
    domain,
    department,
    experience
    from traine
)
select * from typo