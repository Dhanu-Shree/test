{{
    config(
        tags=['mart']
    )
}}
with
employee as (
    select * from  {{ ref('stg_employee') }}
),
days AS (
    SELECT 
        DISTINCT trainingname,
        trainername,
        round(AVG(performance)) AS AveragePerformance,
        DATEDIFF(day, start_date, end_date) AS No_of_Days 
    FROM 
        employee
    GROUP BY 
        trainingname,
        trainername,
        end_date,
        start_date
)
select * from days