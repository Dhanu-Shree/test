{{
    config(
        tags=['mart']
    )
}}

with trainees as (
    select *
    from  {{ ref('stg_trainee') }}
    
),
RankedRows AS (
    SELECT 
        *,
        ROW_NUMBER() OVER (PARTITION BY department ORDER BY experience desc) AS row_num
    FROM 
        trainees
),

highexperience as(
     select
     trainerid,
    trainername,
    domain,
    department,
    experience 
    from RankedRows where row_num=1
)
select * from highexperience