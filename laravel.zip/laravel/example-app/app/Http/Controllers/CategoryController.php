<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;

class CategoryController extends Controller
{
    public function create(){
        $categories=Category::get();
        return view('todo.create',compact('categories'));
    }
    public function index(){
return view('todo.index');
    }

    public function save(Request $request){
        Category::create([
            'name'=>$request->name,
            'description'=>$request->description,
            'is_active'=>$request->is_active== true ?1:0

        ]);
       return redirect('categories/create')->with('status','Category created');

    }
    public function edit($id){
        $user=Category::find($id);

        return view('todo.edit',['categories'=>$user]);
    }
    public function update(Request $request,$id){
        $user=Category::find($id);
        $user->name=$request->input('name');
    $user-> description=$request->input('description');
     $user->is_active=$request->input('is_active');
     $user->save();
    return "Update Successfully <a href='.url('categories').'>Click to update</a>";
    }

}
