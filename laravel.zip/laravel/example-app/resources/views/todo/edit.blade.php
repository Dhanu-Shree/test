<div class="container center-container">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            @if(session('status'))
            <div class="alert alert-success">{{ session('status') }}</div>
            @endif
            <div class="card">
                <div class="card-header">
                    <h4>Categories
                        <a href="{{ url('update/'.$categories->id)}}" class="btn btn-primary float-end">Back</a>
                    </h4>
                </div>
                <div class="card-body">
                <form action="{{ url('update/'.$categories->id)}}" method="GET">
                        @csrf
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="{{ $categories->name }}">
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <input type="text" class="form-control" id="description" name="description" value="{{ $categories->description}}">
                        </div>
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="{{ $categories->is_active }}">
                                <label class="form-check-label" for="is_active">
                                    Is active
                                </label>
                            </div>
                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
    .center-container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh; /* Set the height to the viewport height to center vertically */
    }

    .mb-3 {
        margin-bottom: 15px; /* Add margin between each field */
    }

    .card {
        border: 1px solid #ccc; /* Add border to the card */
        border-radius: 8px; /* Add border radius to the card */
    }

    .card-header {
        background-color: #f0f0f0; /* Add background color to the card header */
        border-bottom: 1px solid #ccc; /* Add border to the card header */
        padding: 10px 15px; /* Add padding to the card header */
    }

    .card-body {
        padding: 20px; /* Add padding to the card body */
    }
</style>
