<div class="container center-container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0 d-inline">Categories</h4>
                    <a href="{{ url('categories/create') }}" class="btn btn-primary float-end">Add category</a>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped text-center">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Is Active</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($categories as $item)
                            <tr>
                                <td>{{ $item->id }}</td>
                                <td>{{ $item->name }}</td>
                                <td>{{ $item->description }}</td>
                                <td>
                                    @if($item->is_active)
                                        Not Completed
                                    @else
                                        Completed
                                    @endif
                                </td>
                                <td>
                                    <a href="edit/{{$categories->id}}" class="btn btn-sm btn-primary">Edit</a>
                                </td>
                                <td>
                                    <a href="#" class="btn btn-sm btn-danger">Delete</a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .card {
        border: 2px solid #ccc;
        border-radius: 15px;
        width: 80%;
        margin: auto;
        margin-top: 20px;
    }

    .card-header {
        background-color: #3490dc;
        border-bottom: 2px solid #ccc;
        border-radius: 15px 15px 0 0;
        padding: 10px 15px;
    }

    .card-header h4 {
        color: white;
        margin-bottom: 0;
    }

    .card-body {
        padding: 20px;
    }

    .table {
        border: 2px solid #dee2e6;
        border-radius: 15px;
    }

    .table th,
    .table td {
        border: 1px solid #dee2e6;
    }

    .table-striped tbody tr:nth-of-type(odd) {
        background-color: #f8f9fa;
    }

    .btn {
        margin-right: 5px;
    }

    .center-container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 80vh;
    }
</style>
