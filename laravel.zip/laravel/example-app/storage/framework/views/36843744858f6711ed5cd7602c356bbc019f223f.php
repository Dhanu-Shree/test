<div class="container">
    <div class="row">
    <div class ="col-md-12"> 
        <div class="card">
            <div class="card-header">
                <h4> Categories
                    <a href="" class="btn btn-primary float-end">Add category</a>
                </h4>
                <div class='card-body'>
                    
</div>
</div>
</div>
</div>
<?php /**PATH C:\Users\DhanuShreeSS\Desktop\laravel\example-app\resources\views/todo.blade.php ENDPATH**/ ?>