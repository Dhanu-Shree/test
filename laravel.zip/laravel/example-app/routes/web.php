<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoryController;

Route::get('categories', [CategoryController::class, 'index']);
Route::get('categories/create', [CategoryController::class, 'create']);

Route::post('categories/create', [CategoryController::class, 'save']);
Route::get('edit/{id}', [CategoryController::class, 'edit']);
Route::post('update/{id}', [CategoryController::class, 'update']);

